
# JotaStore - Site

Este projeto contém os arquivos para o site JotaStore.

## Estrutura para GitHub Pages

- Uploadar os arquivos da raiz e a pasta `assets/` no repositório GitHub.
- Ativar GitHub Pages no ramo `main` raiz.

## Estrutura para Firebase Hosting

- A pasta `public/` contém os arquivos para Firebase Hosting.
- Use o Firebase CLI para deploy:
```
firebase deploy
```

- Arquivos `firebase.json` e `.firebaserc` estão na pasta `jotastore_firebase_hosting`.

## Contato

Desenvolvido com suporte ChatGPT.
